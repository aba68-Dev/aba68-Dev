
const people = ['yosi', 'ryu', 'chun-li', 'ken'];
const age = [25,20,24,26];
console.log(people);

module.exports = {people, age};