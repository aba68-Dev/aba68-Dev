// const name = 'mario'

// console.log(name);


/* const greet = (name) => {
    console.log(`hello, ${name}`);
}
 */
/* greet('Mario');
greet('Chalmers'); */

//Global object

// console.log(global);

