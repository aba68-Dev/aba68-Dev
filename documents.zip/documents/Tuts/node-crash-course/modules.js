const streetFighter = require("./people");

console.log(streetFighter.people, streetFighter.age);